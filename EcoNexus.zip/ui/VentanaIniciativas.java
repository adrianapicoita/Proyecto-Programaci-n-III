package ui;

import models.IniciativaAmbiental;
import models.Tarea;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;

public class VentanaIniciativas extends JFrame {
    private List<IniciativaAmbiental> iniciativas = new ArrayList<>();
    private JTextArea areaIniciativas;

    public VentanaIniciativas() {
        setTitle("Gestión de Iniciativas Ambientales");
        setSize(600, 400);
        setLayout(new BorderLayout());

        areaIniciativas = new JTextArea();
        add(new JScrollPane(areaIniciativas), BorderLayout.CENTER);

        JButton botonAgregar = new JButton("Agregar Iniciativa");
        botonAgregar.addActionListener((ActionEvent e) -> agregarIniciativa());

        JButton botonMostrar = new JButton("Mostrar Iniciativas");
        botonMostrar.addActionListener((ActionEvent e) -> mostrarIniciativas());

        JPanel panel = new JPanel();
        panel.add(botonAgregar);
        panel.add(botonMostrar);
        add(panel, BorderLayout.SOUTH);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void agregarIniciativa() {
        String nombre = JOptionPane.showInputDialog("Nombre de la iniciativa:");
        String region = JOptionPane.showInputDialog("Región:");
        String estado = JOptionPane.showInputDialog("Estado (planificación, ejecución, finalizado):");

        IniciativaAmbiental iniciativa = new IniciativaAmbiental(nombre, region, estado);
        String agregarMas;
        do {
            String descripcion = JOptionPane.showInputDialog("Descripción de tarea:");
            String prioridad = JOptionPane.showInputDialog("Prioridad (Alta, Media, Baja):");
            String estadoTarea = JOptionPane.showInputDialog("Estado de la tarea (iniciada, en proceso, finalizada):");
            String colaboradores = JOptionPane.showInputDialog("Colaboradores:");

            Tarea tarea = new Tarea(descripcion, prioridad, estadoTarea, colaboradores);
            iniciativa.agregarTarea(tarea);
            agregarMas = JOptionPane.showInputDialog("¿Agregar otra tarea? (si/no)");
        } while (agregarMas != null && agregarMas.equalsIgnoreCase("si"));

        iniciativas.add(iniciativa);
    }

    private void mostrarIniciativas() {
        StringBuilder sb = new StringBuilder();
        for (IniciativaAmbiental ini : iniciativas) {
            sb.append(ini.toString()).append("\n");
            for (Tarea t : ini.getTareasOrdenadasPorPrioridad()) {
                sb.append("   - ").append(t.toString()).append("\n");
            }
        }
        areaIniciativas.setText(sb.toString());
    }
}
