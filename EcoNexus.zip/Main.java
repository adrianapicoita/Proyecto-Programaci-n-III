import ui.VentanaIniciativas;

public class Main {
    public static void main(String[] args) {
        new VentanaIniciativas();
    }
}
