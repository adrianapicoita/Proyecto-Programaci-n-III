package models;

import java.util.ArrayList;
import java.util.List;

public class IniciativaAmbiental {
    private String nombre;
    private String region;
    private String estado;
    private List<Tarea> tareas;

    public IniciativaAmbiental(String nombre, String region, String estado) {
        this.nombre = nombre;
        this.region = region;
        this.estado = estado;
        this.tareas = new ArrayList<>();
    }

    public String getNombre() { return nombre; }
    public String getRegion() { return region; }
    public String getEstado() { return estado; }

    public void setEstado(String estado) { this.estado = estado; }

    public void agregarTarea(Tarea t) {
        tareas.add(t);
    }

    public List<Tarea> getTareas() {
        return tareas;
    }

    public List<Tarea> getTareasOrdenadasPorPrioridad() {
        tareas.sort((t1, t2) -> t1.getPrioridad().compareTo(t2.getPrioridad()));
        return tareas;
    }

    @Override
    public String toString() {
        return nombre + " - " + region + " (" + estado + ")";
    }
}
