package models;

public class Tarea {
    private String descripcion;
    private String prioridad;
    private String estado;
    private String colaboradores;

    public Tarea(String descripcion, String prioridad, String estado, String colaboradores) {
        this.descripcion = descripcion;
        this.prioridad = prioridad;
        this.estado = estado;
        this.colaboradores = colaboradores;
    }

    public String getDescripcion() { return descripcion; }
    public String getPrioridad() { return prioridad; }
    public String getEstado() { return estado; }
    public String getColaboradores() { return colaboradores; }

    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public void setPrioridad(String prioridad) { this.prioridad = prioridad; }
    public void setEstado(String estado) { this.estado = estado; }
    public void setColaboradores(String colaboradores) { this.colaboradores = colaboradores; }

    @Override
    public String toString() {
        return "[" + prioridad + "] " + descripcion + " (" + estado + ") - Colaboradores: " + colaboradores;
    }
}
